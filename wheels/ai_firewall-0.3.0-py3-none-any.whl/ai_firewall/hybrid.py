"""HybridDetector — regex first-pass + an optional semantic judge on the gray zone.

It implements the same interface the rest of the library depends on
(``detect()``, ``projections()``, ``patterns``), so it drops into
``Firewall(detector=HybridDetector(...))`` with NO gateway change.

Flow:
  1. Run the fast regex Detector.
  2. If it already returns high/critical → block immediately (skip the costly judge).
  3. Otherwise, if a judge is attached AND the gate says this input is worth it,
     consult the judge; if the judge calls it an attack, upgrade the verdict.

The gate keeps the judge cheap: by default it escalates only inputs the regex already
flagged (to confirm/upgrade) OR clean inputs that trip a cheap "assistant-directed
control word" heuristic. A consumer can pass ``gate=lambda t, d: True`` to judge
everything (max security, max cost) or supply their own policy.
"""
import re

from .detector import Detector, Detection
from .patterns import SEMANTIC_JUDGE

_SEV_ORDER = {None: 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
_SEV_RISK = {None: 0, "low": 20, "medium": 45, "high": 75, "critical": 95}

# Cheap heuristic: control words that suggest the text is trying to steer the assistant.
# A loose gate only costs extra judge calls (the judge is the decider) — never an FP.
_CONTROL_HINTS = re.compile(
    r"\b(?:assistant|instruction|directive|jailbreak|override|pretend|impersonat\w*|"
    r"system\s+prompt|you\s+are|act\s+as|ignore|disregard|guard\s?rail|"
    r"new\s+(?:rule|directive|instruction)|reveal|bypass)\b",
    re.IGNORECASE,
)


def default_gate(text, base_detection) -> bool:
    """Decide whether to spend a judge call on this input."""
    if getattr(base_detection, "is_suspicious", False):
        return True                                   # regex flagged → confirm/upgrade
    if not isinstance(text, str):
        return False
    return bool(_CONTROL_HINTS.search(text))          # clean but borderline → worth a look


class HybridDetector:
    def __init__(self, base: Detector | None = None, judge=None, gate=None):
        self.base = base if base is not None else Detector()
        self.judge = judge
        self.gate = gate if gate is not None else default_gate

    # ---- redaction surface: delegate to the regex base (offset-aligned) ----
    @property
    def patterns(self):
        return self.base.patterns

    def projections(self, text):
        return self.base.projections(text)

    # ---- detection ----
    def detect(self, text) -> Detection:
        d = self.base.detect(text)
        # already blocking on the fast path → don't pay for the judge
        if d.is_suspicious and _SEV_ORDER.get(d.severity, 0) >= _SEV_ORDER["high"]:
            return d
        if self.judge is None:
            return d
        s = text if isinstance(text, str) else str(text)
        try:
            if self.gate(s, d):
                verdict = self.judge.judge(s)
                if getattr(verdict, "is_attack", False):
                    return self._merge(d, verdict)
        except Exception:
            return d                                  # judge/gate failure never blocks
        return d

    @staticmethod
    def _merge(base_detection, verdict) -> Detection:
        sev = verdict.severity if verdict.severity in _SEV_ORDER else "high"
        if _SEV_ORDER.get(base_detection.severity, 0) > _SEV_ORDER.get(sev, 0):
            sev = base_detection.severity
        cats = tuple(base_detection.matched_categories) + (SEMANTIC_JUDGE,)
        return Detection(
            is_suspicious=True,
            matched_patterns=tuple(base_detection.matched_patterns) + ("semantic_judge",),
            matched_categories=cats,
            severity=sev,
            risk_score=min(100, _SEV_RISK.get(sev, 75) + 5 * max(0, len(set(cats)) - 1)),
        )
