"""CrewAI adapter.

Duck-typed on purpose: it wraps anything that looks like a CrewAI tool (an object
exposing ``_run``/``run``) or a plain callable tool, without importing crewai. The
tool's input is guarded and its output sanitized, so a poisoned scrape/result can't
carry an injection back into the agent.
"""

from .generic import guard_callable


def guard_crew_tool(firewall, tool):
    """Return a tool whose input is guarded and output sanitized.

    - object with ``_run``/``run``: that method is wrapped in place and the object
      returned.
    - plain callable: a guarded callable is returned.
    """
    for attr in ("_run", "run"):
        method = getattr(tool, attr, None)
        if callable(method):
            guarded = guard_callable(
                firewall, guard_args=True, sanitize_result=True
            )(method)
            setattr(tool, attr, guarded)
            return tool

    if callable(tool):
        return guard_callable(firewall, guard_args=True, sanitize_result=True)(tool)

    raise TypeError(
        "guard_crew_tool: expected a callable tool or an object exposing run/_run"
    )
