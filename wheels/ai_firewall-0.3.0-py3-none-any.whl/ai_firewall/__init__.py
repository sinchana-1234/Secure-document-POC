"""ai_firewall — framework-agnostic prompt-injection firewall.

Pure-Python core (zero runtime dependencies). Optional framework adapters live in
``ai_firewall.integrations`` and are imported lazily.
"""

from .firewall import Firewall
from .detector import Detector, Detection
from .policy import Policy, Mode, Action, decide
from .errors import PromptInjectionError, DocumentBlockedError
from .gateway import SecureGateway
from .hybrid import HybridDetector, default_gate
from .judges import JudgeVerdict, LLMJudge, EmbeddingJudge
from .canary import CanaryGuard, make_canary
from .session import SessionMonitor

__all__ = [
    "Firewall",
    "SecureGateway",
    "Detector",
    "Detection",
    "Policy",
    "Mode",
    "Action",
    "decide",
    "PromptInjectionError",
    "DocumentBlockedError",
    # optional advanced layers (semantic judge / canary / behavioral)
    "HybridDetector",
    "default_gate",
    "JudgeVerdict",
    "LLMJudge",
    "EmbeddingJudge",
    "CanaryGuard",
    "make_canary",
    "SessionMonitor",
]

__version__ = "0.3.0"
