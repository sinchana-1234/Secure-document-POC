"""The Firewall facade — one configurable object guarding all four surfaces.

  * guard_input        — chat / agent prompts (may block in enforce mode)
  * scan_document      — RAG ingestion verdict ("should I embed this?")
  * sanitize_document  — RAG ingestion redaction (embed-safe text)
  * filter_retrieval   — sanitize retrieved chunks before they hit the LLM context
  * guard_tool_output  — sanitize scraped/DB text fed back to an agent (never raises)

The asymmetry is deliberate: input/document guards may *block*; retrieval and tool
output may only *sanitize* — that text is attacker-influenced content the system
already pulled in, and raising there would let an attacker crash the agent.
"""

import logging

from .normalize import normalize_text, truncate
from .detector import Detector, Detection
from .policy import Policy, Mode, Action, decide
from .errors import PromptInjectionError

_default_logger = logging.getLogger("ai_firewall")


class Firewall:
    def __init__(self, policy: Policy | None = None,
                 detector: Detector | None = None, logger=None):
        self.policy = policy or Policy()
        self.detector = detector or Detector()
        self.logger = logger or _default_logger

    # ------------------------------------------------------------------ input ----
    def guard_input(self, text: str) -> str:
        clean = truncate(normalize_text(text), self.policy.max_input_length)
        detection = self.detector.detect(clean)
        action = (decide(detection.severity, self.policy)
                  if detection.is_suspicious else Action.ALLOW)
        self._log("input", action, detection, clean)
        if self.policy.mode == Mode.ENFORCE and action in (Action.BLOCK, Action.CHALLENGE):
            raise PromptInjectionError(detection, action.value)
        return clean

    # --------------------------------------------------------------- document ----
    def scan_document(self, text: str) -> Detection:
        return self.detector.detect(self._clean_doc(text))

    def sanitize_document(self, text: str) -> str:
        clean = self._clean_doc(text)
        sanitized = self._redact(clean)
        if sanitized != clean:
            self._log("document", Action.FLAG, self.detector.detect(clean), clean)
        return sanitized

    # -------------------------------------------------------------- retrieval ----
    def filter_retrieval(self, chunks, text_of=None, set_text=None):
        """Sanitize each retrieved chunk before it enters the LLM context.

        - plain string chunks: returns sanitized strings.
        - ``text_of`` given: extracts the chunk text, sanitizes it, and writes it back.
          Pass ``set_text(chunk, sanitized)`` for unambiguous write-back; otherwise a
          dict chunk's matching field is replaced in place. If neither can locate the
          field, this raises ValueError — it never silently emits an unredacted chunk.
        """
        out = []
        for chunk in chunks:
            raw = chunk if text_of is None else text_of(chunk)
            sanitized = self._redact(self._clean_doc(raw))

            if text_of is None:
                out.append(sanitized)
            elif set_text is not None:
                out.append(set_text(chunk, sanitized))
            elif isinstance(chunk, dict):
                new = dict(chunk)
                replaced = [k for k, v in new.items() if v == raw]
                if not replaced:
                    raise ValueError(
                        "filter_retrieval could not locate the text field to redact; "
                        "pass set_text=callable(chunk, sanitized) to write it back."
                    )
                for k in replaced:
                    new[k] = sanitized
                out.append(new)
            else:
                raise ValueError(
                    "filter_retrieval needs set_text for non-dict chunks when "
                    "text_of is given (cannot write the sanitized text back safely)."
                )
        return out

    # ------------------------------------------------------------- tool output ----
    def guard_tool_output(self, text: str) -> str:
        return self._redact(self._clean_doc(text))

    # ----------------------------------------------------------------- output ----
    def guard_output(self, text: str) -> str:
        """Egress guard — sanitize the model's RESPONSE before it reaches the user.

        Redacts any injected/echoed payload the model parroted back (e.g. a leaked
        instruction). SANITIZE-ONLY — never raises, mirroring the document / tool
        surfaces: an output guard must not crash a response. Pair it with
        ``SecureGateway(protect=[...])`` to also strip a leaked system prompt /
        secret from the output.
        """
        clean = self._clean_doc(text)
        sanitized = self._redact(clean)
        if sanitized != clean:
            self._log("output", Action.FLAG, self.detector.detect(clean), clean)
        return sanitized

    # ----------------------------------------------------------------- helpers ----
    def _clean_doc(self, text) -> str:
        """Normalize and apply the document-length cap (bounds regex cost on the
        attacker-influenced document / tool surfaces)."""
        if not isinstance(text, str):
            text = str(text)
        return truncate(normalize_text(text), self.policy.max_document_length)

    def _redact(self, text: str) -> str:
        """Blank every injected span by OFFSET across all detection projections.

        Because detection runs on confusable/leet-folded shadows (1:1 codepoint maps,
        offset-preserving), a match found only on a folded shadow is excised from the
        original here — so obfuscated payloads are neutralized, not just detected.
        """
        projections = self.detector.projections(text)
        spans = [
            (m.start(), m.end())
            for _name, regex, _cat in self.detector.patterns
            for proj in projections
            for m in regex.finditer(proj)
            if m.end() > m.start()
        ]
        if not spans:
            return text

        spans.sort()
        merged = [spans[0]]
        for start, end in spans[1:]:
            last_start, last_end = merged[-1]
            if start <= last_end:
                merged[-1] = (last_start, max(last_end, end))
            else:
                merged.append((start, end))

        parts, prev = [], 0
        for start, end in merged:
            parts.append(text[prev:start])
            parts.append(self.policy.redaction_placeholder)
            prev = end
        parts.append(text[prev:])
        return "".join(parts)

    def _log(self, surface, action, detection, text):
        if action == Action.ALLOW:
            return
        preview = ""
        if self.policy.log_preview_chars > 0:
            preview = " preview=" + repr(text[: self.policy.log_preview_chars])
        self.logger.warning(
            "ai_firewall surface=%s action=%s severity=%s risk=%s categories=%s len=%d%s",
            surface, getattr(action, "value", action), detection.severity,
            detection.risk_score, ",".join(detection.matched_categories),
            len(text), preview,
        )
