"""Confusable (homoglyph) and leetspeak folding.

NFKC normalization deliberately leaves cross-script lookalikes alone — Cyrillic "о"
(U+043E) and Latin "o" are different characters that render identically, and NFKC
keeps them distinct. Attackers exploit exactly that. These folds map such lookalikes
(and common leetspeak digit substitutions) down to a Latin "skeleton" used as an
EXTRA detection pass. They are never used to mutate user-facing text — only to widen
what the detector can see.
"""

import re

# Curated set of the cross-script characters actually abused in injection attacks:
# Cyrillic and Greek letters that are visual twins of Latin letters.
_CONFUSABLES = {
    # --- Cyrillic lowercase ---
    "а": "a", "е": "e", "о": "o", "р": "p", "с": "c",
    "х": "x", "у": "y", "і": "i", "ѕ": "s", "ј": "j",
    "н": "h", "к": "k", "м": "m", "т": "t", "в": "b",
    # --- Cyrillic uppercase ---
    "А": "A", "Е": "E", "О": "O", "Р": "P", "С": "C",
    "Х": "X", "У": "Y", "І": "I", "Ѕ": "S", "К": "K",
    "М": "M", "Т": "T", "Н": "H", "В": "B",
    # --- Greek ---
    "ο": "o", "α": "a", "ε": "e", "ρ": "p", "υ": "u",
    "ι": "i", "κ": "k", "ν": "v", "χ": "x",
    "Ο": "O", "Α": "A", "Ε": "E", "Ρ": "P", "Χ": "X",
    "Ι": "I", "Κ": "K", "Μ": "M", "Τ": "T",
}

# Common leetspeak digit/symbol -> letter substitutions.
_LEET = {
    "0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t",
    "@": "a", "$": "s",
}


def fold_confusables(text: str) -> str:
    """Map cross-script homoglyphs to their Latin lookalike."""
    return "".join(_CONFUSABLES.get(ch, ch) for ch in text)


def fold_leet(text: str) -> str:
    """Map common leetspeak substitutions back to letters."""
    return "".join(_LEET.get(ch, ch) for ch in text)


# A run of single letters/digits each followed by one separator (space, dot, dash,
# underscore), repeated 3+ times before a final char — i.e. 4+ spaced-out single
# characters: "i g n o r e", "i.g.n.o.r.e", "r-e-v-e-a-l". The >=4 threshold keeps
# ordinary prose (initials, two-letter words, short lists like "a b c") untouched.
_SPACED_CHARS = re.compile(r"\b(?:\w[ .\-_]){3,}\w\b")


def fold_separators(text: str) -> str:
    """Collapse 'spaced-out' single characters back into a word so the pattern
    library can see the real token ('i g n o r e' -> 'ignore'). This is the classic
    way attackers smuggle a trigger word past whole-word matching.

    NOT length-preserving (it removes the separators), so — unlike fold_confusables
    / fold_leet — it must NOT be used for offset-based redaction. It is a DETECT-ONLY
    view (see Detector.detect): it can flip the verdict to suspicious, but the
    redactor still works off the length-aligned projections.
    """
    return _SPACED_CHARS.sub(lambda m: re.sub(r"[ .\-_]", "", m.group(0)), text)
