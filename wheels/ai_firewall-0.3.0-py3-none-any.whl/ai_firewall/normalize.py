"""Text normalization — defeats invisible-character and compatibility-form evasion.

This is the FIRST line of the firewall: before any pattern runs, text is folded to a
canonical form so that zero-width splits, bidi overrides, full-width characters, and
control bytes cannot be used to slip an attack past the detector.

Note: NFKC does NOT handle cross-script homoglyphs (Cyrillic/Greek lookalikes) or
leetspeak — those are handled separately in ``confusables`` as detection-time folds.
"""

import re
import unicodedata

# Zero-width, bidirectional, and other invisible/format control characters that are
# used to split tokens ("ig<zwsp>nore") or visually reorder text.
_INVISIBLE = re.compile(
    "[­​-‏‪-‮⁠-⁤⁪-⁯﻿]"
)

# C0 and C1 control characters, excluding the common whitespace \t \n \r.
_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]")

# Unicode Tag block (U+E0000–U+E007F): invisible characters that shadow ASCII and
# are used to smuggle hidden instructions some models silently decode. Strip them.
_TAGS = re.compile(r"[\U000E0000-\U000E007F]")


def normalize_text(text: str) -> str:
    """Return a canonical form: NFKC, with invisible, control and Tag characters stripped."""
    if not isinstance(text, str):
        text = str(text)
    text = unicodedata.normalize("NFKC", text)
    text = _INVISIBLE.sub("", text)
    text = _CONTROL.sub("", text)
    text = _TAGS.sub("", text)
    return text


def truncate(text: str, max_length: int | None) -> str:
    """Cap text length (bounds regex cost and oversized-prompt abuse)."""
    if max_length is not None and len(text) > max_length:
        return text[:max_length]
    return text
